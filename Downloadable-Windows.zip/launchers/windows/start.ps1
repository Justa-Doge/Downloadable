$ErrorActionPreference = "Stop"
try {
  $projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
  Set-Location $projectRoot
  $links = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links"
  if (Test-Path -LiteralPath $links) {
    $entries = $env:PATH -split ";"
    if ($entries -notcontains $links) { $env:PATH = "$links;$env:PATH" }
  }
  $ffmpegBin = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg.Shared_*\ffmpeg-*-full_build-shared\bin" -Directory -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($ffmpegBin -and ($env:PATH -split ';') -notcontains $ffmpegBin.FullName) { $env:PATH = "$($ffmpegBin.FullName);$env:PATH" }
  if (-not (Test-Path ".venv\Scripts\python.exe")) {
    throw "Python environment is missing. Run Downloadable.cmd first."
  }
  & ".venv\Scripts\python.exe" "helper\helper.py"
  if ($LASTEXITCODE -ne 0) { throw "The helper exited with code $LASTEXITCODE." }
} catch {
  Write-Host ""
  Write-Host "Downloadable could not start:" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Yellow
  exit 1
}
